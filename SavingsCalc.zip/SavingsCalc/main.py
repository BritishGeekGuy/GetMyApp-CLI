print("Please enter amount of 1p coins")
pence_1 = int(input("1p Amount: "))
print("Please enter amount of 2p coins")
pence_2 = int(input("2p Amount: "))
print("Please enter amount of 5p coins")
pence_5 = int(input("5p Amount: "))
print("Please enter amount of 10p coins")
pence_10 = int(input("10p Amount: "))
print("Please enter amount of 20p coins")
pence_20 = int(input("20p Amount: "))
print("Please enter the amount of 50p coins")
pence_50 = int(input("50p Amount: "))
print("Please enter amount of £1 coins")
pound = int(input("£1 Amount: "))

new_pence_2 = pence_2 * 2
new_pence_5 = pence_5 * 5
new_pence_10 = pence_10 * 10
new_pence_20 = pence_20 * 20
new_pence_50 = pence_50 * 50
new_pound = pound * 100

total_pence = pence_1 + new_pence_2 + new_pence_5 + new_pence_10 + new_pence_20 + new_pence_50 + new_pound

total_pounds = total_pence / 100

print(" ")
print(f"Total Saved in Pence: {total_pence}")
print(f"Total Saved in Pounds: £{total_pounds}")
input()