from plyer import notification
title = 'Hey!'
message = 'Edit this for your project!'
notification.notify(title= title,
                    message= message,
                    app_icon = None,
                    timeout= 3,
                    toast=True)
